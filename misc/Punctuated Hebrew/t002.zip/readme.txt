

The Hebrew Bible with vowels according to the Masoretic Text

(c) 2014 all rights reserved to Mechon Mamre for this HTML version
http://www.mechon-mamre.org/                mtr@mechon-mamre.org


The Hebrew Bible (no vowels) for the Palm Pilot at
http://www.mechon-mamre.org/pdbtnk.htm


Contents in Original Hebrew Bible Order:

Torah - Genesis, Exodus, Leviticus, Numbers, Deuteronomy

Prophets - Joshua, Judges, Samuel, Kings, Isaiah, Jeremiah, Ezekiel,
Hosea, Joel, Amos, Obadiah, Jonah, Micah, Nahum, Habakkuk, Zephaniah,
Haggai, Zechariah, Malachi

Writings - Chronicles, Psalms, Job, Proverbs, Ruth, Song of Songs,
Ecclesiastes, Lamentations, Esther, Daniel, Ezra / Nehemiah


The Hebrew text with vowels in this HTML edition of the Hebrew Bible
is based on the Aleppo Codex and the other early manuscripts that are
close to it, using the method of the Rav Mordechai Breuer, taken from
our online version at:

http://www.mechon-mamre.org/i/t/t0.htm

We also have online the Hebrew Bible with cantillation marks at:

http://www.mechon-mamre.org/c/ct/c0.htm

Our Bibles conform completely to the RaMBaM's Laws of Torah Scrolls
Chapter 8's details on correct division of paragraphs (according to
the Yemenite manuscripts of Mishneh Torah, which differ from the usual
Vilna editon) and it is proper for a scribe to use them as the basis
for writing a kosher Torah scroll.


This HTML version is readable in Microsoft Internet Explorer 5 or
later on Win9x or later with Hebrew Support Package installed
(available from Windows Update).  For more Hebrew support info, see
our:

http://www.mechon-mamre.org/tech.htm


This zip ordinarily unzips into a folder named t ; to use this HTML
collection, open t0.htm in this t folder.

Last updated:  26 November 2014

